$(document).ready(function() {

  // the basics
  // ----------

  var substringMatcher = function(strs) {
    return function findMatches(q, cb) {
      var matches, substringRegex;

      // an array that will be populated with substring matches
      matches = [];

      // regex used to determine if a string contains the substring `q`
      substrRegex = new RegExp(q, 'i');

      // iterate through the pool of strings and for any string that
      // contains the substring `q`, add it to the `matches` array
      $.each(strs, function(i, str) {
        if (substrRegex.test(str)) {
          matches.push(str);
        }
      });

      cb(matches);
    };
  };

var jokes = joke: [
'I\'m tired of following my dreams. I\'m just going to ask them where they are going and meet up with them later.',
'Did you hear about the guy whose whole left side was cut off? He\'s all right now.',
'Why didn’t the skeleton cross the road? Because he had no guts.',
'What did one nut say as he chased another nut? I\'m a cashew!',
'Where do fish keep their money? In the riverbank',
'I accidentally took my cats meds last night. Don’t ask meow.',
'Chances are if you\'ve seen one shopping center, you\'ve seen a mall.',
'Dermatologists are always in a hurry. They spend all day making rash decisions.',
'I knew I shouldn\'t steal a mixer from work, but it was a whisk I was willing to take.',
'I won an argument with a weather forecaster once. His logic was cloudy...',
'How come the stadium got hot after the game? Because all of the fans left.',
'Why do seagulls fly over the ocean?" "Because if they flew over the bay, we\'d call them bagels.',
'Why was it called the dark ages? Because of all the knights.',
'A steak pun is a rare medium well done.',
'Why did the tomato blush? Because it saw the salad dressing.',
'Did you hear the joke about the wandering nun? She was a roman catholic.',
'What creature is smarter than a talking parrot? A spelling bee.',
'I\'ll tell you what often gets over looked... garden fences. ',
'Why did the kid cross the playground? To get to the other slide.',
'Why do birds fly south for the winter? Because it\'s too far to walk.'];

  $('#the-basics .typeahead').typeahead({
    hint: true,
    highlight: true,
    minLength: 1
  },
  {
    name: 'jokes',
    source: substringMatcher(jokes)
  });

  // bloodhound
  // ----------

  // constructs the suggestion engine
  var jokes = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.whitespace,
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    // `jokes` is an array of state names defined in "The Basics"
    local: jokes
  });

  $('#bloodhound .typeahead').typeahead({
    hint: true,
    highlight: true,
    minLength: 1
  },
  {
    name: 'jokes',
    source: jokes
  });

  /* prefetch

  var countries = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.whitespace,
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    // url points to a json file that contains an array of country names, see
    // https://github.com/twitter/typeahead.js/blob/gh-pages/data/countries.json
    prefetch: '../data/countries.json'
  });

  // passing in `null` for the `options` arguments will result in the default
  // options being used
  $('#prefetch .typeahead').typeahead(null, {
    name: 'countries',
    source: countries
  });

  // remote
  // ------

  var bestPictures = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: '../data/films/post_1960.json',
    remote: {
      url: '../data/films/queries/%QUERY.json',
      wildcard: '%QUERY'
    }
  });

  $('#remote .typeahead').typeahead(null, {
    name: 'best-pictures',
    display: 'value',
    source: bestPictures
  });

  // default suggestions
  // -------------------

  var nflTeams = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace('team'),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    identify: function(obj) { return obj.team; },
    prefetch: '../data/nfl.json'
  });

  function nflTeamsWithDefaults(q, sync) {
    if (q === '') {
      sync(nflTeams.get('Detroit Lions', 'Green Bay Packers', 'Chicago Bears'));
    }

    else {
      nflTeams.search(q, sync);
    }
  }

  $('#default-suggestions .typeahead').typeahead({
    minLength: 0,
    highlight: true
  },
  {
    name: 'nfl-teams',
    display: 'team',
    source: nflTeamsWithDefaults
  });

  // custom templates
  // ----------------

  $('#custom-templates .typeahead').typeahead(null, {
    name: 'best-pictures',
    display: 'value',
    source: bestPictures,
    templates: {
      empty: [
        '<div class="empty-message">',
          'unable to find any Best Picture winners that match the current query',
        '</div>'
      ].join('\n'),
      suggestion: Handlebars.compile('<div><strong>{{value}}</strong> – {{year}}</div>')
    }
  });

  // multiple datasets
  // -----------------

  var nbaTeams = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace('team'),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: '../data/nba.json'
  });

  var nhlTeams = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace('team'),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    prefetch: '../data/nhl.json'
  });

  $('#multiple-datasets .typeahead').typeahead({
    highlight: true
  },
  {
    name: 'nba-teams',
    display: 'team',
    source: nbaTeams,
    templates: {
      header: '<h3 class="league-name">NBA Teams</h3>'
    }
  },
  {
    name: 'nhl-teams',
    display: 'team',
    source: nhlTeams,
    templates: {
      header: '<h3 class="league-name">NHL Teams</h3>'
    }
  });

  // scrollable dropdown menu
  // ------------------------

  $('#scrollable-dropdown-menu .typeahead').typeahead(null, {
    name: 'countries',
    limit: 10,
    source: countries
  });

  // rtl
  // ---

  var arabicPhrases = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.whitespace,
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    local: [
      "الإنجليزية",
      "نعم",
      "لا",
      "مرحبا",
      "أهلا"
    ]
  });

  $('#rtl-support .typeahead').typeahead({
    hint: false
  },
  {
    name: 'arabic-phrases',
    source: arabicPhrases
  });*/
});

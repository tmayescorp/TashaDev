var substringMatcher = function(strs) {
  return function findMatches(q, cb) {
    var matches, substringRegex;

    // an array that will be populated with substring matches
    matches = [];

    // regex used to determine if a string contains the substring `q`
    substrRegex = new RegExp(q, 'i');

    // iterate through the pool of strings and for any string that
    // contains the substring `q`, add it to the `matches` array
    $.each(strs, function(i, str) {
      if (substrRegex.test(str)) {
        matches.push(str);
      }
    });

    cb(matches);
  };
};

/* dad jokes data */
var jokes = [
'What is a centipedes\'s favorite Beatle song?  I want to hold your hand, hand, hand, hand...',
'My first time using an elevator was an uplifting experience. The second time let me down.',
'To be Frank, I\'d have to change my name.',
'Slept like a log last night … woke up in the fireplace.',
'What do you call a female snake. misssssssss',
'Why does a Moon-rock taste better than an Earth-rock? Because it\'s a little meteor.',
'I thought my wife was joking when she said she\'d leave me if I didn\'t stop signing "I\'m A Believer"... Then I saw her face.',
'I/’m only familiar with 25 letters in the English language. I don’t know why.',
'What do you call two barracuda fish?  A Pairacuda!',
'What did the father tomato say to the baby tomato whilst on a family walk? Ketchup.',
'Why is Peter Pan always flying? Because he Neverlands.',
'What do you do on a remote island? Try and find the TV island it belongs to.',
'Did you know that protons have mass? I didn\'t even know they were catholic.',
'Dad I’m hungry’ … ‘Hi hungry I’m dad',
'I was fired from the keyboard factory yesterday.  I wasn\'t putting in enough shifts.',
'Whoever invented the knock-knock joke should get a no bell prize.',
'Wife: Honey I’m pregnant.',
'Me: Well…. what do we do now?',
'Wife: Well, I guess we should go to a baby doctor.',
'Me: Hm.. I think I’d be a lot more comfortable going to an adult doctor.',
'Have you heard the story about the magic tractor? It drove down the road and turned into a field.',
'When will the little snake arrive? I don\'t know but he won\'t be long...',
'Why was Pavlov\'s beard so soft?  Because he conditioned it.',
'I\'m tired of following my dreams. I\'m just going to ask them where they are going and meet up with them later.',
'Did you hear about the guy whose whole left side was cut off? He\'s all right now.',
'Why didn’t the skeleton cross the road? Because he had no guts.',
'What did one nut say as he chased another nut?  I\'m a cashew!',
'Where do fish keep their money? In the riverbank',
'I accidentally took my cats meds last night. Don’t ask meow.',
'Chances are if you\'ve seen one shopping center, you\'ve seen a mall.',
'Dermatologists are always in a hurry. They spend all day making rash decisions. ',
'I knew I shouldn\'t steal a mixer from work, but it was a whisk I was willing to take.',
'I won an argument with a weather forecaster once. His logic was cloudy...',
'How come the stadium got hot after the game? Because all of the fans left.',
'"Why do seagulls fly over the ocean?" "Because if they flew over the bay, we\'d call them bagels."',
'Why was it called the dark ages? Because of all the knights. ',
'A steak pun is a rare medium well done.',
'Why did the tomato blush? Because it saw the salad dressing.',
'Did you hear the joke about the wandering nun? She was a roman catholic.',
'What creature is smarter than a talking parrot? A spelling bee.',
'I\'ll tell you what often gets over looked... garden fences.',
'Why did the kid cross the playground? To get to the other slide.',
'Why do birds fly south for the winter? Because it\'s too far to walk.'
];

$('#the-basics .typeahead').typeahead({
  hint: true,
  highlight: true,
  minLength: 1
},
{
  name: 'jokes',
  source: substringMatcher(jokes)
});
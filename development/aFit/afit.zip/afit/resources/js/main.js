//  server work init
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function () {
    //navigator.serviceWorker.register("/src/jquery-1.10.2.min.js");
    navigator.serviceWorker.register("/src/sw.js");
    //navigator.serviceWorker.register("/src/handlebars.js");
    //navigator.serviceWorker.register("/src/main-typeahead.js");
    //navigator.serviceWorker.register("/src/bundle-typeahead.js");
    //navigator.serviceWorker.register("/src/examples-typeahead.js");
    //navigator.serviceWorker.register("/src/data.js");
  });
}

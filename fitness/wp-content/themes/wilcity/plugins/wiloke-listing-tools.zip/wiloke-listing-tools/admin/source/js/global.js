/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "https://demo.wilcityapp.com/wp-content/plugins/wiloke-listing-tools/admin/source/js/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./admin/source/dev/global.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./admin/source/dev/global.js":
/*!************************************!*\
  !*** ./admin/source/dev/global.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("/**\n * Created by pirates on 7/4/18.\n */\n(function ($) {\n  'use strict';\n\n  var $id = function (selector) {\n    return $(document.getElementById(selector));\n  };\n\n  function hasChangedRestaurant() {\n    var $hasChanged = $('#wilcity_changed_menu_restaurant');\n    $hasChanged.val('yes');\n    updateMenuRestanrantKeys();\n  }\n\n  function updateMenuRestanrantKeys() {\n    var $input = $('#wilcity_menu_restaurant_keys');\n    var $restaurantMenuGroup = $('.postbox[id^=wilcity_restaurant_menu_group_]');\n    var aMenuKeys = [];\n    $restaurantMenuGroup.each(function () {\n      aMenuKeys.push($(this).attr('id'));\n    });\n    $input.val(aMenuKeys.join());\n  }\n\n  function listenChangeRestaurantMenu() {\n    var $restaurantMenuGroup = $('.postbox[id^=wilcity_restaurant_menu_group_]');\n    $restaurantMenuGroup.find('input, textarea, select').on('keydown change', function () {\n      hasChangedRestaurant();\n    });\n    $restaurantMenuGroup.find('.cmb2-upload-list, .cmb2-remove-file-button, .cmb-remove-group-row').on('click', function () {\n      hasChangedRestaurant();\n    });\n  }\n\n  function deleteRestaurantMenu($restaurantBox) {\n    $restaurantBox.on('click', function (event) {\n      event.preventDefault();\n      var $event = $(event.currentTarget),\n          iWantToRemoveIt = confirm('Are you sure that you want to delete this menu?'),\n          $numberOfMenus = $('#wilcity_number_restaurant_menus');\n\n      if (iWantToRemoveIt) {\n        var numberOfMenus = parseInt($numberOfMenus.val(), 10);\n        $numberOfMenus.val(numberOfMenus - 1);\n        $event.closest('.postbox.cmb2-postbox').remove();\n        hasChangedRestaurant();\n      }\n    });\n  }\n\n  function reInitNewGroup($parent) {\n    var $repeatGroup = $parent.find('.cmb-repeatable-group'); // Init time/date/color pickers\n\n    CMB2.initPickers($parent.find('input[type=\"text\"].cmb2-timepicker'), $parent.find('input[type=\"text\"].cmb2-datepicker'), $parent.find('input[type=\"text\"].cmb2-colorpicker')); // Init code editors.\n\n    CMB2.initCodeEditors($parent.find('.cmb2-textarea-code:not(.disable-codemirror)')); // Insert toggle button into DOM wherever there is multicheck. credit: Genesis Framework\n\n    $('<p><span class=\"button-secondary cmb-multicheck-toggle\">' + cmb2_l10.strings.check_toggle + '</span></p>').insertBefore('.cmb2-checkbox-list:not(.no-select-all)'); // Make File List drag/drop sortable:\n\n    CMB2.makeListSortable(); // Make Repeatable fields drag/drop sortable:\n\n    CMB2.makeRepeatableSortable();\n    $parent.on('change', '.cmb2_upload_file', function () {\n      cmb.media.field = $(this).attr('id');\n      $id(cmb.media.field + '_id').val('');\n    }); // Media/file management.on('click', '.cmb-multicheck-toggle', CMB2.toggleCheckBoxes).on('click', '.cmb2-upload-button', CMB2.handleMedia).on('click', '.cmb-attach-list li, .cmb2-media-status .img-status img, .cmb2-media-status .file-status > span', CMB2.handleFileClick).on('click', '.cmb2-remove-file-button', CMB2.handleRemoveMedia)\n    // Repeatable content.on('click', '.cmb-add-group-row', CMB2.addGroupRow).on('click', '.cmb-add-row-button', CMB2.addAjaxRow).on('click', '.cmb-remove-group-row', CMB2.removeGroupRow).on('click', '.cmb-remove-row-button', CMB2.removeAjaxRow)\n    // Ajax oEmbed display.on('keyup paste focusout', '.cmb2-oembed', CMB2.maybeOembed)\n    // Reset titles when removing a row.on('cmb2_remove_row', '.cmb-repeatable-group', CMB2.resetTitlesAndIterator).on('click', '.cmbhandle, .cmbhandle + .cmbhandle-title', CMB2.toggleHandle);\n\n    if ($repeatGroup.length) {\n      $repeatGroup.on('cmb2_add_row', CMB2.emptyValue).on('cmb2_add_row', CMB2.setDefaults).filter('.sortable').each(function () {\n        // Add sorting arrows\n        $(this).find('.cmb-remove-group-row-button').before('<a class=\"button-secondary cmb-shift-rows move-up alignleft\" href=\"#\"><span class=\"' + cmb2_l10.up_arrow_class + '\"></span></a> <a class=\"button-secondary cmb-shift-rows move-down alignleft\" href=\"#\"><span class=\"' + cmb2_l10.down_arrow_class + '\"></span></a>');\n      }).on('click', '.cmb-shift-rows', CMB2.shiftRows);\n    }\n  }\n\n  function addNewRestaurantMenu() {\n    var aNewOrderIds = [];\n    $('#wilcity-add-menu-restaurant').on('click', function () {\n      var $group = $('.postbox.cmb2-postbox[id^=\"wilcity_restaurant_menu_group\"]'),\n          $newGroupIDs = $('#wilcity_added_fields');\n      var $closestGroup = $group.last();\n      var $newGroup = $closestGroup.clone();\n      var totalItems = $newGroup.find('.cmb-repeatable-grouping').length;\n      var $repeaterItems = $newGroup.find('.cmb-repeatable-grouping');\n      var $repeaterGroup = $newGroup.find('.cmb-repeatable-group');\n      var $groupDescription = $repeaterGroup.find('.cmb-group-description');\n      var $addGroupRow = $repeaterGroup.find('.cmb-add-group-row');\n      var $removeGroup = $repeaterGroup.find('.cmb-remove-group-row');\n      $('#wilcity_number_restaurant_menus').val($group.length + 1);\n\n      for (var i = 1; i < totalItems; i++) {\n        $newGroup.find('#cmb-group-wilcity_restaurant_menu_group-' + i).remove();\n      }\n\n      var oldGroupOrder = $group.length - 1,\n          newGroupOrder = oldGroupOrder + 1; // set order id\n\n      aNewOrderIds.push(newGroupOrder);\n      $newGroupIDs.val(aNewOrderIds.join(','));\n      $newGroup.find('.handlediv').attr('aria-expanded', true);\n      var aNeedReplaceOrderOfFields = {\n        'input': ['wilcity_group_title_', 'wilcity_group_icon_', 'wilcity_group_description_']\n      };\n\n      for (let fieldType in aNeedReplaceOrderOfFields) {\n        for (let order in aNeedReplaceOrderOfFields[fieldType]) {\n          let fieldKey = aNeedReplaceOrderOfFields[fieldType][order];\n          $newGroup.find(fieldType + '[for=\"' + fieldKey + oldGroupOrder + '\"]').attr('for', fieldKey + newGroupOrder);\n          $newGroup.find(fieldType + '[name=\"' + fieldKey + oldGroupOrder + '\"]').attr('name', fieldKey + newGroupOrder);\n          $newGroup.find(fieldType + '[id=\"' + fieldKey + oldGroupOrder + '\"]').attr('id', fieldKey + newGroupOrder);\n        }\n      }\n\n      $repeaterItems.find('input, textarea').each(function () {\n        let getName = $(this).attr('name');\n        let newName = getName.replace('wilcity_restaurant_menu_group_' + oldGroupOrder, 'wilcity_restaurant_menu_group_' + newGroupOrder);\n        let oldID = $(this).attr('id');\n        let newID = oldID.replace('wilcity_restaurant_menu_group_' + oldGroupOrder, 'wilcity_restaurant_menu_group_' + newGroupOrder);\n        $(this).attr('name', newName);\n        $(this).attr('id', newID);\n      });\n      $newGroup.find('.ui-sortable-handle span').html('Restaurant Menu Settings ' + newGroupOrder);\n      $newGroup.find('.cmb-remove-field-row').remove();\n      $repeaterGroup.data('groupid', 'wilcity_restaurant_menu_group_' + newGroupOrder);\n      $repeaterGroup.attr('data-groupid', 'wilcity_restaurant_menu_group_' + newGroupOrder);\n      $repeaterGroup.attr('id', 'wilcity_restaurant_menu_group_' + newGroupOrder + '_repeat');\n      $addGroupRow.data('selector', 'wilcity_restaurant_menu_group_' + newGroupOrder + '_repeat');\n      $addGroupRow.attr('data-selector', 'wilcity_restaurant_menu_group_' + newGroupOrder + '_repeat');\n      $removeGroup.data('selector', 'wilcity_restaurant_menu_group_' + newGroupOrder + '_repeat');\n      $removeGroup.attr('data-selector', 'wilcity_restaurant_menu_group_' + newGroupOrder + '_repeat');\n      var $oldRow = $repeaterItems.first();\n      var $row = $oldRow.clone();\n      var nodeName = $row.prop('nodeName') || 'div';\n      $row.find('.cmb-add-row-button').prop('disabled', false);\n      $row.find('.cmb2-upload-file').val();\n      $row.find('.cmb2-media-status').empty();\n      $row.find('.cmb2_textarea, .regular-text').val('');\n      $row.find('.regular-text').attr('value', '');\n      $row.find('.cmb2_textarea').html('');\n      $row.find('.cmb2-media-status').attr('id', 'wilcity_restaurant_menu_group_0_' + newGroupOrder + '_gallery-status');\n      $row.find('input.cmb2-upload-file').attr('id', 'wilcity_restaurant_menu_group_0_' + newGroupOrder + '_gallery');\n      var $newRow = $('<' + nodeName + ' id=\"cmb-group-wilcity_restaurant_menu_group_' + newGroupOrder + '-0\" class=\"postbox cmb-row cmb-repeatable-grouping\" data-iterator=\"' + 0 + '\">' + $row.html() + '</' + nodeName + '>');\n      $repeaterItems.remove();\n      $groupDescription.after($newRow);\n      CMB2.afterRowInsert($newRow);\n      CMB2.triggerElement($repeaterGroup, {\n        type: 'cmb2_add_row',\n        group: true\n      }, $newRow);\n      let wrapperID = 'wilcity_restaurant_menu_group_' + newGroupOrder;\n      $closestGroup.after('<div id=\"' + wrapperID + '\" class=\"postbox cmb2-postbox\">' + $newGroup.html() + '</div>');\n      var $newGroupController = $('#wilcity_restaurant_menu_group_' + newGroupOrder);\n      reInitNewGroup($newGroupController);\n      deleteRestaurantMenu($newGroupController.find('.wilcity-delete-menu-restaurant'));\n      hasChangedRestaurant();\n      $newGroupController.on('click', 'h2.hndle', function (event) {\n        event.preventDefault();\n        $newGroupController.toggleClass('closed');\n      });\n    });\n  }\n\n  $(document).ready(function () {\n    $('#wilcity_business_hourMode').on('change', function () {\n      let val = $(this).val();\n\n      if (val == 'open_for_selected_hours') {\n        $('.wilcity-bh-settings').removeClass('hidden');\n      } else {\n        $('.wilcity-bh-settings').addClass('hidden');\n      }\n    });\n    $('.wil-select-business-hour').select2();\n    $('#frequency').on('change', function () {\n      let val = $(this).val();\n\n      if (val == 'weekly') {\n        $('.cmb-row.cmb2-id-specifyDays').show();\n      } else {\n        $('.cmb-row.cmb2-id-specifyDays').hide();\n      }\n    }).trigger('change');\n    deleteRestaurantMenu($('.wilcity-delete-menu-restaurant'));\n    addNewRestaurantMenu();\n    listenChangeRestaurantMenu();\n  });\n})(jQuery);\n\n//# sourceURL=webpack:///./admin/source/dev/global.js?");

/***/ })

/******/ });